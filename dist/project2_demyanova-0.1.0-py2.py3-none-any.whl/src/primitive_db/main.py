#!/usr/bin/env python3

print("DB project is running!")
